<?php
class Router {
    public static function run() {
    }
}
